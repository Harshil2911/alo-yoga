import React from 'react';
import Link from 'next/link';

const categories = [
  {
    name: 'Yoga',
    image: 'https://ext.same-assets.com/2506137374/4194560810.jpeg',
    link: '/collections/yoga'
  },
  {
    name: 'Pilates',
    image: 'https://ext.same-assets.com/2506137374/3441074039.jpeg',
    link: '/collections/pilates'
  },
  {
    name: 'Lounge',
    image: 'https://ext.same-assets.com/2506137374/4197024985.jpeg',
    link: '/collections/lounge-shop'
  },
  {
    name: 'Run',
    image: 'https://ext.same-assets.com/2506137374/1436670580.jpeg',
    link: '/collections/run'
  },
  {
    name: 'Court Sports',
    image: 'https://ext.same-assets.com/2506137374/2765851231.jpeg',
    link: '/collections/tennis-inspired'
  },
  {
    name: 'Train',
    image: 'https://ext.same-assets.com/2506137374/2472802085.jpeg',
    link: '/collections/train'
  }
];

const CategoriesSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-center text-2xl md:text-3xl font-semibold mb-2">Shop by Activity</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-8">
          {categories.map((category) => (
            <Link
              href={category.link}
              key={category.name}
              className="group"
            >
              <div className="overflow-hidden rounded-sm">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full aspect-[3/4] object-cover group-hover:scale-105 transition duration-300"
                />
              </div>
              <h3 className="mt-2 text-center font-medium">{category.name}</h3>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoriesSection;
