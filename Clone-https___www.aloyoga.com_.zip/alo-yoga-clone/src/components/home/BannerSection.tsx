import React from 'react';
import Link from 'next/link';

const BannerSection = () => {
  return (
    <section className="py-8 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="relative">
            <img
              src="https://ext.same-assets.com/2506137374/3802734129.jpeg"
              alt="Trend Report"
              className="w-full aspect-[1.5/1] object-cover"
            />
            <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white p-6">
              <span className="bg-black bg-opacity-30 px-4 py-2 text-xs tracking-wider uppercase">Trend Report</span>
              <h2 className="mt-4 text-xl md:text-2xl">Seasons shift & so does the opportunity to reset your closet.</h2>
              <Link
                href="/pages/vision-board"
                className="mt-4 text-sm font-medium border-b border-white pb-1 transition hover:opacity-80"
              >
                Shop Spring '25
              </Link>
            </div>
          </div>

          <div className="relative">
            <img
              src="https://ext.same-assets.com/2506137374/1514546570.jpeg"
              alt="The Final Few"
              className="w-full aspect-[1.5/1] object-cover"
            />
            <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white p-6">
              <span className="bg-black bg-opacity-30 px-4 py-2 text-xs tracking-wider uppercase">The Final Few</span>
              <h2 className="mt-4 text-xl md:text-2xl">Snag your favorite pieces before they're gone for good.</h2>
              <Link
                href="/collections/almost-gone-1"
                className="mt-4 text-sm font-medium border-b border-white pb-1 transition hover:opacity-80"
              >
                Shop Now
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BannerSection;
