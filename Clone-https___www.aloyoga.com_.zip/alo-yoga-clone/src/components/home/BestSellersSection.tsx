import React from 'react';
import Link from 'next/link';

const bestSellers = [
  {
    id: 1,
    name: 'Airbrush Heart Throb Bra',
    color: 'Black/White',
    price: 78,
    image: 'https://ext.same-assets.com/4123685135/1871198989.jpeg',
    customerFavorite: true,
    link: '/products/w9680r-airbrush-heart-throb-bra-black-white'
  },
  {
    id: 2,
    name: 'Airbrush High-Waist Heart Throb Legging',
    color: 'Black/White',
    price: 118,
    image: 'https://ext.same-assets.com/4123685135/3362487122.jpeg',
    customerFavorite: true,
    link: '/products/w51298r-airbrush-high-waist-heart-throb-legging-black-white'
  },
  {
    id: 3,
    name: 'Airlift Alignment Bra',
    color: 'Black/White',
    price: 88,
    image: 'https://ext.same-assets.com/4123685135/1612082799.jpeg',
    customerFavorite: false,
    link: '/products/w9824r-airlift-alignment-bra-black-white'
  },
  {
    id: 4,
    name: 'Airlift High-Waist Alignment Legging',
    color: 'Black/White',
    price: 128,
    image: 'https://ext.same-assets.com/4123685135/4228601681.jpeg',
    customerFavorite: false,
    link: '/products/w54180r-airlift-high-waist-alignment-legging-black-white'
  }
];

const BestSellersSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-center text-2xl md:text-3xl font-semibold mb-2">THE REVIEWS ARE IN</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {bestSellers.map((product) => (
            <Link href={product.link} key={product.id} className="group">
              <div className="relative overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full aspect-[3/4] object-cover group-hover:scale-105 transition duration-300"
                />
                {product.customerFavorite && (
                  <div className="absolute top-2 left-2 bg-white px-2 py-1 text-xs font-medium">
                    Customer Favorite
                  </div>
                )}
              </div>

              <div className="mt-4">
                <h3 className="font-medium">{product.name} - {product.color}</h3>
                <p className="text-sm mt-1">${product.price.toFixed(2)}</p>
                <p className="text-sm mt-3 text-gray-600">
                  "Great sports bra! Flattering, supportive, good quality and material. My new go to."
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BestSellersSection;
