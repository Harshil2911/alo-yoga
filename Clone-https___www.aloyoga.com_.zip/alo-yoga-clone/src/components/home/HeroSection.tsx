import React from 'react';
import Link from 'next/link';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const HeroSection = () => {
  return (
    <section className="relative">
      <Carousel className="w-full">
        <CarouselContent>
          <CarouselItem>
            <div className="relative h-[70vh] w-full overflow-hidden">
              <img
                src="https://ext.same-assets.com/2506137374/4123685135.jpeg"
                alt="Alo Yoga model"
                className="object-cover w-full h-full"
              />
              <div className="absolute inset-0 bg-black bg-opacity-20 flex flex-col justify-center items-center text-center text-white p-4">
                <h2 className="text-3xl md:text-5xl font-bold mb-4">Free Soul in LA</h2>
                <p className="text-lg md:text-xl mb-6">Summer color stories made for paradise</p>
                <Link
                  href="/collections/new-arrivals"
                  className="bg-white text-black px-8 py-3 font-medium tracking-wider uppercase text-sm hover:bg-gray-100 transition"
                >
                  Explore Now
                </Link>
              </div>
            </div>
          </CarouselItem>

          <CarouselItem>
            <div className="relative h-[70vh] w-full overflow-hidden">
              <img
                src="https://ext.same-assets.com/2506137374/3287523999.jpeg"
                alt="Alo Yoga travel"
                className="object-cover w-full h-full"
              />
              <div className="absolute inset-0 bg-black bg-opacity-20 flex flex-col justify-center items-center text-center text-white p-4">
                <h2 className="text-3xl md:text-5xl font-bold mb-4">She's On The Move</h2>
                <p className="text-lg md:text-xl mb-6">Outfits made for adventure</p>
                <Link
                  href="/collections/travel-in-alo"
                  className="bg-white text-black px-8 py-3 font-medium tracking-wider uppercase text-sm hover:bg-gray-100 transition"
                >
                  Shop Travel
                </Link>
              </div>
            </div>
          </CarouselItem>
        </CarouselContent>
        <CarouselPrevious className="absolute left-4 z-10 bg-white bg-opacity-60 text-black border-none hover:bg-white hover:bg-opacity-90" />
        <CarouselNext className="absolute right-4 z-10 bg-white bg-opacity-60 text-black border-none hover:bg-white hover:bg-opacity-90" />
      </Carousel>
    </section>
  );
};

export default HeroSection;
