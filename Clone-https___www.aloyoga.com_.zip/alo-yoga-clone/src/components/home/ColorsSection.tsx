import React from 'react';
import Link from 'next/link';

const colors = [
  {
    name: 'Smoky Quartz',
    description: 'Realign your wardrobe with this new gem of a color.',
    image: 'https://ext.same-assets.com/2506137374/3994791408.jpeg',
    link: '/collections/smoky-quartz'
  },
  {
    name: 'Espresso',
    description: 'A deeply saturated shade with all-year appeal.',
    image: 'https://ext.same-assets.com/2506137374/1385595391.jpeg',
    link: '/collections/espresso-1'
  },
  {
    name: 'Warm Butter',
    description: 'A melt-worthy color for melt-worthy styles.',
    image: 'https://ext.same-assets.com/2506137374/3922914016.jpeg',
    link: '/collections/warm-butter'
  },
  {
    name: 'Spruce Green',
    description: 'Get a daily dose of greens with this vibrant hue.',
    image: 'https://ext.same-assets.com/2506137374/478201814.jpeg',
    link: '/collections/spruce-green'
  },
  {
    name: 'Navy',
    description: 'This modern classic goes with everything.',
    image: 'https://ext.same-assets.com/2506137374/434281904.jpeg',
    link: '/collections/womens-navy'
  },
  {
    name: 'Mushroom',
    description: 'An ultra-soft neutral sprung just in time for spring.',
    image: 'https://ext.same-assets.com/2506137374/3392092307.jpeg',
    link: '/collections/mushroom'
  }
];

const ColorsSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-center text-2xl md:text-3xl font-semibold mb-8">SHOP BY COLOR</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {colors.map((color) => (
            <Link href={color.link} key={color.name} className="group">
              <div className="overflow-hidden">
                <img
                  src={color.image}
                  alt={color.name}
                  className="w-full aspect-[3/4] object-cover group-hover:scale-105 transition duration-300"
                />
              </div>

              <div className="mt-4 text-center">
                <h3 className="font-semibold uppercase text-sm tracking-wide">{color.name}</h3>
                <p className="text-sm mt-1">{color.description}</p>
                <p className="text-sm mt-2 font-medium underline">Shop {color.name}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ColorsSection;
