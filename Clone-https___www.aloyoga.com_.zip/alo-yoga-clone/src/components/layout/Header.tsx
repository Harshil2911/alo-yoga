import React from 'react';
import Link from 'next/link';
import { Search, ShoppingBag, Heart, User, Menu } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-white border-b border-gray-200">
      <div className="hidden md:block bg-alo-black text-white text-xs tracking-wide text-center p-1">
        SPRING ENERGY SHOP NEW HUES
      </div>
      <div className="hidden md:block bg-gray-100 text-black text-xs tracking-wide text-center p-1">
        SHOP SAME-DAY DELIVERY SEE AT CHECKOUT
      </div>

      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="md:hidden">
          <button className="hover:text-gray-600">
            <Menu size={20} />
          </button>
        </div>

        <div className="flex items-center space-x-8">
          <Link href="/" className="text-2xl font-bold">
            <svg width="40" height="14" viewBox="0 0 40 14" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21.8127 0.0996094C16.9482 0.0996094 13.4316 3.25948 13.4316 7.00293C13.4316 10.7464 16.9482 13.9062 21.8127 13.9062C26.6771 13.9062 30.1937 10.7464 30.1937 7.00293C30.1937 3.25948 26.6771 0.0996094 21.8127 0.0996094ZM21.8127 11.3809C18.8525 11.3809 16.8472 9.45855 16.8472 7.00293C16.8472 4.5473 18.8525 2.625 21.8127 2.625C24.7728 2.625 26.7781 4.5473 26.7781 7.00293C26.7781 9.45855 24.7728 11.3809 21.8127 11.3809Z" fill="black" />
              <path d="M7.54357 0.0996094C2.67908 0.0996094 0 3.25948 0 7.00293C0 10.7464 2.67908 13.9062 7.54357 13.9062C12.408 13.9062 14.8371 10.7464 14.8371 7.00293C14.8371 3.25948 12.408 0.0996094 7.54357 0.0996094ZM7.54357 11.3809C4.58342 11.3809 3.41562 9.45855 3.41562 7.00293C3.41562 4.5473 4.58342 2.625 7.54357 2.625C10.5037 2.625 11.5215 4.5473 11.5215 7.00293C11.5215 9.45855 10.5037 11.3809 7.54357 11.3809Z" fill="black" />
              <path d="M36.5842 0.396484C34.3291 0.396484 32.8986 1.82226 32.8986 3.625C32.8986 5.42774 34.3291 6.85351 36.5842 6.85351C38.8394 6.85351 40.2699 5.42774 40.2699 3.625C40.2699 1.82226 38.8394 0.396484 36.5842 0.396484ZM36.5842 4.52344C35.6914 4.52344 35.2035 4.14062 35.2035 3.625C35.2035 3.10937 35.6914 2.72656 36.5842 2.72656C37.4771 2.72656 37.9649 3.10937 37.9649 3.625C37.9649 4.14062 37.4771 4.52344 36.5842 4.52344Z" fill="black" />
            </svg>
          </Link>

          <nav className="hidden md:flex space-x-6">
            <Link href="/collections/womens-shop-all" className="text-sm font-medium uppercase tracking-wide">
              Women
            </Link>
            <Link href="/collections/mens-shop-all" className="text-sm font-medium uppercase tracking-wide">
              Men
            </Link>
            <Link href="/collections/accessories-shop-all" className="text-sm font-medium uppercase tracking-wide">
              Accessories
            </Link>
            <Link href="/collections/shoes" className="text-sm font-medium uppercase tracking-wide">
              Shoes
            </Link>
          </nav>
        </div>

        <div className="flex items-center space-x-4">
          <button className="hover:text-gray-600">
            <Search size={20} />
          </button>
          <button className="hover:text-gray-600 hidden md:block">
            <User size={20} />
          </button>
          <button className="hover:text-gray-600 hidden md:block">
            <Heart size={20} />
          </button>
          <button className="hover:text-gray-600">
            <ShoppingBag size={20} />
          </button>
        </div>
      </div>

      {/* Mobile announcement bar */}
      <div className="md:hidden bg-alo-black text-white text-xs tracking-wide text-center p-1">
        FREE SHIPPING & RETURNS
      </div>
    </header>
  );
};

export default Header;
