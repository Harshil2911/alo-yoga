import React from 'react';
import Link from 'next/link';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Instagram, Facebook, Twitter, Youtube } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-alo-black text-white">
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <h3 className="font-medium text-sm uppercase mb-4">Customer Service</h3>
          <ul className="space-y-2 text-sm">
            <li><Link href="#" className="hover:text-gray-300">Help Center</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Track My Order</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Shipping</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Returns & Exchanges</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Gift Card</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Gift Card Balance</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Size Guide</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Reviews</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="font-medium text-sm uppercase mb-4">My Account</h3>
          <ul className="space-y-2 text-sm">
            <li><Link href="#" className="hover:text-gray-300">Login or Register</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Order History</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Shipping & Billing</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Refer a Friend</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="font-medium text-sm uppercase mb-4">Information</h3>
          <ul className="space-y-2 text-sm">
            <li><Link href="#" className="hover:text-gray-300">Alo Access</Link></li>
            <li><Link href="#" className="hover:text-gray-300">We Are Alo</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Blog</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Yoga Studios</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Stores</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Events</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Pro Program</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Careers</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Alo Moves</Link></li>
            <li><Link href="#" className="hover:text-gray-300">Alo Gives</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="font-medium text-sm uppercase mb-4">Get the App</h3>
          <Link href="#" className="inline-block mb-8">
            <img
              src="https://ext.same-assets.com/2024933735/651774675.svg"
              alt="Alo App - iOS App Store"
              className="h-10"
            />
          </Link>

          <h3 className="font-medium text-sm uppercase mb-4">Follow Us</h3>
          <div className="flex space-x-4 mb-8">
            <Link href="#" className="hover:text-gray-300">
              <Instagram size={20} />
            </Link>
            <Link href="#" className="hover:text-gray-300">
              <Facebook size={20} />
            </Link>
            <Link href="#" className="hover:text-gray-300">
              <Twitter size={20} />
            </Link>
            <Link href="#" className="hover:text-gray-300">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C6.477 2 2 6.477 2 12C2 17.523 6.477 22 12 22C17.523 22 22 17.523 22 12C22 6.477 17.523 2 12 2ZM14.5 10.297C13.93 10.297 13.5 9.827 13.5 9.203C13.5 8.637 13.93 8.203 14.5 8.203C15.07 8.203 15.5 8.637 15.5 9.203C15.5 9.827 15.07 10.297 14.5 10.297ZM7.6 14.297C7.6 12.977 8.71 11.203 10.5 11.203C11.307 11.203 11.956 11.488 12.42 11.949C12.42 11.949 12.603 11.297 13.5 11.297C13.773 11.297 14 11.552 14 11.797V15.891C14 15.891 14.34 16.172 14.7 16.172C15.31 16.172 15.6 15.477 15.6 15.477C15.6 17.031 14.31 17.797 13.2 17.797C11.73 17.797 11.2 16.891 11.2 16.891C10.63 17.547 9.89 17.797 9.1 17.797C8.1 17.797 7.6 17.102 7.6 14.297ZM9.3 14.297C9.3 15.797 9.44 16.172 9.93 16.172C10.362 16.172 10.9 15.648 10.9 15.125V12.891C10.56 12.594 10.21 12.594 9.93 12.594C9.43 12.594 9.3 13.477 9.3 14.297Z" fill="currentColor"/>
              </svg>
            </Link>
            <Link href="#" className="hover:text-gray-300">
              <Youtube size={20} />
            </Link>
          </div>

          <h3 className="font-medium text-sm uppercase mb-4">Sign up for our newsletter</h3>
          <div className="flex">
            <Input
              type="email"
              placeholder="Email Address"
              className="bg-white text-black"
            />
            <Button variant="default" className="bg-white text-black ml-2">
              →
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 text-xs border-t border-gray-800">
        <p>© 2025 Alo, LLC. All Rights Reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
