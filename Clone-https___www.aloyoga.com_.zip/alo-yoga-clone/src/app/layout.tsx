import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Alo Yoga | Yoga leggings, clothes, and accessories for studio to street",
  description: "Shop the best yoga wear & accessories for yoga and working out. Wear-tested by yogis for the best fit. Shop celeb-approved yoga pants, workout tights, leggings, capris & lounge for women & men.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="font-sans">
        {children}
      </body>
    </html>
  );
}
