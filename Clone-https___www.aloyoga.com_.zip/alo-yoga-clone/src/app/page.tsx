import HeroSection from "@/components/home/HeroSection";
import CategoriesSection from "@/components/home/CategoriesSection";
import BestSellersSection from "@/components/home/BestSellersSection";
import ColorsSection from "@/components/home/ColorsSection";
import BannerSection from "@/components/home/BannerSection";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

export default function Home() {
  return (
    <main>
      <Header />
      <HeroSection />
      <CategoriesSection />
      <BestSellersSection />
      <BannerSection />
      <ColorsSection />
      <Footer />
    </main>
  );
}
